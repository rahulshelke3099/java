package com.psl.emp.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import com.psl.emp.bean.Employee;
@Repository("dao")
public class EmployeeeDaoImpl extends JdbcDaoSupport implements EmployeeDao{
	@Autowired
	DataSource dataSource;
	
	
	@PostConstruct
	public void init()
	{
		this.setDataSource(dataSource);
	}
	
	@Override
	public Employee addEmployee(final Employee emp) {
		// TODO Auto-generated method stub
		String sql="Insert into employeejava values(?,?,?)";
		return this.getJdbcTemplate().execute(sql,new PreparedStatementCallback<Employee>() {

			@Override
			public Employee doInPreparedStatement(PreparedStatement pstmt)
					throws SQLException, DataAccessException {
				// TODO Auto-generated method stub
				pstmt.setInt(1, emp.getEmpId());
				pstmt.setString(2, emp.getEmpName());
				pstmt.setInt(3, emp.getEmpSal());
				int row=pstmt.executeUpdate();
				if(row>0)
				{
					return emp;
				}else
				return null;
			}
		});
		
	}

	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		
		String sql="select * from employeejava";
		
		return this.getJdbcTemplate().query(sql, new RowMapper<Employee>()
				{

					@Override
					public Employee mapRow(ResultSet rs, int rows)
							throws SQLException {
						// TODO Auto-generated method stub
					Employee emp=new Employee();
					emp.setEmpId(rs.getInt("empId"));
					emp.setEmpName(rs.getString("empName"));
					emp.setEmpSal(rs.getInt("empSal"));
					return emp;
					}
			
				});
	}

}

package com.psl.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.psl.bean.Product;
import com.psl.service.ProductService;


@Controller
public class ProductController {

	@Autowired
    ProductService service;
	
	@RequestMapping(value="/product/{id}" ,produces=MediaType.APPLICATION_JSON_UTF8_VALUE)
	public @ResponseBody Product getProductById(@PathVariable("id") String id)
	{
		return service.getProductById(id);
	}
	
	@RequestMapping("/product/getAll")
	public @ResponseBody HashMap<String,Product> getAllProducts()
	{
		return service.getAllProducts();
	}
	@RequestMapping("/product/delete/{id}")
	public @ResponseBody Product deleteprod(@PathVariable("id") String id)
	{
		return service.deleteProduct(id);
	}
	
	@RequestMapping(value="/product/add", method=RequestMethod.PUT,headers="Accept=Application/json")
	public @ResponseBody Product addprod(@RequestBody Product prod)
	{
		return service.addProduct(prod);
	}
}

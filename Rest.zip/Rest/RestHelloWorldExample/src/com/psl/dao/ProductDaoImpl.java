package com.psl.dao;

import java.util.HashMap;

import org.springframework.stereotype.Repository;

import com.psl.bean.Product;

@Repository("dao")
public class ProductDaoImpl implements ProductDao{
	
	static HashMap<String, Product> map;
	
	static
	{
		map=new HashMap<String, Product>();
		map.put("1", new Product("1","Iphone",50000));
		map.put("2", new Product("2","Laptop",30000));
		map.put("3", new Product("3","ac",70000));
		map.put("4", new Product("4","samsung",60000));
	}


	@Override
	public HashMap<String, Product> getAllProducts() {
		// TODO Auto-generated method stub
		return map;
	}

	@Override
	public Product getProductById(String prodId) {
		// TODO Auto-generated method stub
		return map.get(prodId);
	}

	@Override
	public Product deleteProduct(String id) {
		// TODO Auto-generated method stub
		return map.remove(id);
	}

	@Override
	public Product addProduct(Product prod) {
		// TODO Auto-generated method stub
		map.put(prod.getProdId(),prod);
		return prod;
	}
	

}

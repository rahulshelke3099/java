package com.psl.service;

import java.util.HashMap;

import com.psl.bean.Product;

public interface ProductService {

	public Product getProductById(String prodId);
	public HashMap<String,Product> getAllProducts();
	public Product deleteProduct(String id);
	public Product addProduct(Product prod);
}

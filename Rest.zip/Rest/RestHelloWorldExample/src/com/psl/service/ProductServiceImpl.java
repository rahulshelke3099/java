package com.psl.service;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.psl.bean.Product;
import com.psl.dao.ProductDao;

@Service("service")
public class ProductServiceImpl implements ProductService {
@Autowired
ProductDao dao;
	@Override
	public Product getProductById(String prodId) {
		// TODO Auto-generated method stub
		return dao.getProductById(prodId);
	}

	@Override
	public HashMap<String, Product> getAllProducts() {
		// TODO Auto-generated method stub
		return dao.getAllProducts();
	}

	@Override
	public Product deleteProduct(String id) {
		// TODO Auto-generated method stub
		return dao.deleteProduct(id);
	}

	@Override
	public Product addProduct(Product prod) {
		// TODO Auto-generated method stub
		return dao.addProduct(prod);
	}

}
